<!DOCTYPE html>
<html>
<head>
	<title>Working on it..</title>
	<link rel="stylesheet" type="text/css" href="working.css">

</head>
<body>
<h1>Ooops Page Not Found</h1>
<p class="zoom-area">The page you are looking for does not exist yet.</p>
<center><h3>We are still working on it....</h3></center>
<section class="error-container">
  <span>4</span>
  <span><span class="screen-reader-text">0</span></span>
  <span>4</span>
</section>
<div class="link-container">
  <a  href="homepage.php" class="more-link">Go Home</a>
</div>
<p class="zoom-area" style="font-size: 15px;">Polytechnic University of the Philippines - Scholarship and Financial Assistance Services Management Information System alpha v.0.1</p>
</body>
</html>

